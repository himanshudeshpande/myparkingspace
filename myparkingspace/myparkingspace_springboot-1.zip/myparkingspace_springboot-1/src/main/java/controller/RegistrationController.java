package controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hibernate.Users;
import microservices.CreateSession;
import microservices.CreateUser;
import microservices.ReadUser;
import model.UserRegistrationDetails;

@CrossOrigin
@RestController
@RequestMapping("/registration")
public class RegistrationController 
{
	@PostMapping("/userregistration")
	public int registerUser(@RequestBody UserRegistrationDetails det)
	{
		CreateUser cu = new CreateUser();
		CreateSession cs = new CreateSession();
		boolean res = cu.createUser(cs.getSession(), det.toUsers());
		if(!res)
		{
			cs.closeSession();
			return -2;
		}
		else
		{
			ReadUser ru = new ReadUser();
			Users user = ru.readUser(cs.getSession(), det.getEmail());
			if(user!=null)
			{
				cs.closeSession();
				return user.getId();
			}
			else
			{
				cs.closeSession();
				return -1;
			}
				
		}
	}
}
