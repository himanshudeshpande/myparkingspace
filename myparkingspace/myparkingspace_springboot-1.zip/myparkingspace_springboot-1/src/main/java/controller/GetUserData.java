package controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import hibernate.Users;
import microservices.CreateSession;
import microservices.ReadUser;
import model.UserId;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class GetUserData 
{
	
	@PostMapping("/getProfile")
	public String getProfile(@RequestBody UserId u_id)
	{
		CreateSession cs = new CreateSession();
		ReadUser ru = new ReadUser();
		Users user = ru.readUser(cs.getSession(), u_id.getId());
		String json_string = new Gson().toJson(user);
		cs.closeSession();
		return json_string;
	}
}
