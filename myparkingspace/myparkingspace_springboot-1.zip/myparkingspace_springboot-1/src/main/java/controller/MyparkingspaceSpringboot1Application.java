package controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import hibernate.Name;
import hibernate.Users;
import microservices.CreateSession;
import microservices.CreateUser;

@SpringBootApplication
public class MyparkingspaceSpringboot1Application 
{
	public static void main(String[] args) 
	{
//		Name name = new Name();
//		name.setFirst_name("Himanshu");
//		name.setLast_name("Deshpande");
//		Users user = new Users();
//		user.setName(name);
//		user.setEmail("deshpande.himanshu123@gmail.com");
//		user.setMobile(8855929001L);
//		user.setPassword("admin");
//		CreateSession cs = new CreateSession();
//		CreateUser cu = new CreateUser();
//		cu.createUser(cs.getSession(), user);
//		cs.closeSession();
		SpringApplication.run(MyparkingspaceSpringboot1Application.class, args);
	}
}