package hibernate;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name="user_documents")
@Table(name="user_documents")
public class Documents 
{
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int id;
		
		@Column(nullable=false)
		private String type;
		
		@Column(nullable=false)
		private String file_path;
		
		@ManyToOne
		private Users user_documents;

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getFile_path() {
			return file_path;
		}

		public void setFile_path(String file_path) {
			this.file_path = file_path;
		}

		public Users getUser_documents() {
			return user_documents;
		}

		public void setUser_documents(Users user_documents) {
			this.user_documents = user_documents;
		}

		public int getId() {
			return id;
		}
		

}
