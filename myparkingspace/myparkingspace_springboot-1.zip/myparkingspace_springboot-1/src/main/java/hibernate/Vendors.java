package hibernate;

import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity(name="vendors")
@Table(name="vendors")
public class Vendors 
{
	@Id
	@GeneratedValue (strategy=GenerationType.AUTO) 
	private int id;
	
	@Column(nullable=false)
	private String name;
	
	
	@Column(nullable=false)
	private Date date_register;
	
	@Column(nullable=false)
	private String date_start;
	
	@Embedded
	private Address address;

	@ManyToMany(mappedBy="vendors")
	private List<Categories> category;
	
	@OneToMany(mappedBy="vendor")
	private List<SpotTypes> spot_type;
	
	
	
	
	public List<SpotTypes> getSpot_type() {
		return spot_type;
	}

	public void setSpot_type(List<SpotTypes> spot_type) {
		this.spot_type = spot_type;
	}

	public Date getDate_register() {
		return date_register;
	}

	public void setDate_register(Date date_register) {
		this.date_register = date_register;
	}

	public String getDate_start() {
		return date_start;
	}

	public void setDate_start(String date_start) {
		this.date_start = date_start;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Categories> getCatergory() {
		return category;
	}

	public void setCatergory(List<Categories> catergory) {
		this.category = catergory;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}


	public Date getDateofregister() 
	{
		return date_register;
	}

	public void setDateofregister(String dateofregister) 
	{
		this.date_register = date_register;
	}

	public String getDateofstart() 
	{
		return date_start;
	}

	public void setDateofstart(String date_start) 
	{
		this.date_start = date_start;
	}

	public int getId() 
	{
		return id;
	}
	
	
	
}
