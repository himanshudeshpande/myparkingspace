package hibernate;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name="users")
@Table(name="users")
public class Users 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;

	@Embedded
	private Name name;

	@Column(nullable=false, unique=true)
	private String email;

	@Column(nullable=false, unique=true)
	private long mobile;

	@Column(nullable=false)
	private String password;

	@OneToMany(mappedBy="user_documents")
	private List<Documents> documents;

	@OneToMany(mappedBy="user")
	private List<Vehicles> vehicles;

	public List<Vehicles> getVehicles() 
	{
		return vehicles;
	}

	public void setVehicles(List<Vehicles> vehicles) 
	{
		this.vehicles = vehicles;
	}

	public List<Documents> getDocuments() 
	{
		return documents;
	}

	public void setDocuments(List<Documents> documents) 
	{
		this.documents = documents;
	}

	public Name getName() 
	{
		return name;
	}

	public void setName(Name name) 
	{
		this.name = name;
	}


	public String getEmail() 
	{
		return email;
	}

	public void setEmail(String email) 
	{
		this.email = email;
	}

	public long getMobile() 
	{
		return mobile;
	}

	public void setMobile(long mobile) 
	{
		this.mobile = mobile;
	}

	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public int getId() 
	{
		return id;
	}

	@Override
	public String toString() {
		return "Users [id=" + id + ", name=" + name + ", email=" + email + ", mobile=" + mobile + ", password="
				+ password + ", documents=" + documents + ", vehicles=" + vehicles + "]";
	}
	

}
