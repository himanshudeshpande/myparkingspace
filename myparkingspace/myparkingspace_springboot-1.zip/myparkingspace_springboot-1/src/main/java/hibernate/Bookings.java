package hibernate;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity(name="bookings")
@Table(name="bookings")
public class Bookings 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(nullable=false)
	private String type;
	
	@Column(nullable=false)
	private Date date;
	
	@Column(nullable=false)
	private Time start_time;
	
	@Column(nullable=false)
	private Time end_time;
	
	@ManyToOne
	private Vehicles vehicle;
	
	@OneToOne
	private Payments payment;
	
	public Payments getPayment() {
		return payment;
	}

	public void setPayment(Payments payment) {
		this.payment = payment;
	}

	public Vehicles getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicles vehicle) {
		this.vehicle = vehicle;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Time getStart_time() {
		return start_time;
	}

	public void setStart_time(Time start_time) {
		this.start_time = start_time;
	}

	public Time getEnd_time() {
		return end_time;
	}

	public void setEnd_time(Time end_time) {
		this.end_time = end_time;
	}

	public Time getTime_in() {
		return time_in;
	}

	public void setTime_in(Time time_in) {
		this.time_in = time_in;
	}

	public Time getTime_out() {
		return time_out;
	}

	public void setTime_out(Time time_out) {
		this.time_out = time_out;
	}

	public List<SpotTypes> getSpot_types() {
		return spot_types;
	}

	public void setSpot_types(List<SpotTypes> spot_types) {
		this.spot_types = spot_types;
	}

	public int getId() {
		return id;
	}

	@Column(nullable=false)
	private Time time_in;
	
	@Column(nullable=false)
	private Time time_out;
	
	@OneToMany(mappedBy="booking")
	private List<SpotTypes> spot_types;
	

}
