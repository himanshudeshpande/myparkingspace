package hibernate;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity(name="categories")
@Table(name="categories")
public class Categories 
{

	@Id
	@GeneratedValue (strategy=GenerationType.AUTO) 
	private int id;
	
	@Column(nullable=false,unique=true)
	private String category;
	
	
	@ManyToMany
	private List<Vendors> vendors;
	


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public List<Vendors> getVendors() {
		return vendors;
	}


	public void setVendors(List<Vendors> vendors) {
		this.vendors = vendors;
	}


	public int getId() {
		return id;
	}
	
	
}
