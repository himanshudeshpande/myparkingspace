package microservices;

import org.hibernate.Session;
import org.hibernate.Transaction;

import hibernate.Users;

public class CreateUser 
{
	public boolean createUser(Session s, Users user)
	{
		try
		{
			Transaction t = s.beginTransaction();
			s.save(user);
			t.commit();
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
}
