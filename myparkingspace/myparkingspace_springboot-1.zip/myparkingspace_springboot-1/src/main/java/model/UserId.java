package model;

public class UserId 
{
	private String id;

	public int getId() 
	{
		return Integer.parseInt(id);
	}

	public void setId(String id) 
	{
		this.id = id;
	}
	
	
}
